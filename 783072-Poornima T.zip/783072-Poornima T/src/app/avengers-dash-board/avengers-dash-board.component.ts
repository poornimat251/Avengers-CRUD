import { Component } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import {ApiService } from '../shared/api.service';
import { AvengersModel } from './avengers-dash-board.model';

@Component({
  selector: 'app-avengers-dash-board',
  templateUrl: './avengers-dash-board.component.html',
  styleUrls: ['./avengers-dash-board.component.css']
})
export class AvengersDashBoardComponent {
  formvalue !: FormGroup;
  avengersModelObj: AvengersModel = new AvengersModel();
  avengersdata: any;
  showAdd !:boolean;
  showUpdate!:boolean;
  constructor(private formbuilder: FormBuilder, private api: ApiService,private router:Router) {

  }
  
  ngOnInit() {
    this.formvalue = this.formbuilder.group({
      AvengerName: [''],
      PlaceOfOrigin: [''],
      Gender: [''],
      Hair: [''],
      Eyes: [''],
      AvengerPowers:  [''],
      img: ['']
      
    })
   this.getAllAvengers();
  }
  getAllAvengers() {
    this.api.getAllAvengers().subscribe(
      res => {
        this.avengersdata = res;
      })
  }
  fetchAvg(avn:any){
    this.router.navigate(['/avengers',avn.id,avn.AvengerName,avn.PlaceOfOrigin,avn.Gender,avn.Hair,avn.Eyes,avn.AvengerPowers,avn.img]);

}
clickAddAvenger(){
  this.formvalue.reset();
  this.showAdd=true;
  this.showUpdate=false;
}
postAvengerDetails() {
  this.avengersModelObj.AvengerName = this.formvalue.value.AvengerName;
  this.avengersModelObj.PlaceOfOrigin = this.formvalue.value.PlaceOfOrigin;
  this.avengersModelObj.Gender = this.formvalue.value.Gender;
  this.avengersModelObj.Hair = this.formvalue.value.Hair;
  this.avengersModelObj.Eyes = this.formvalue.value.Eyes;
  this.avengersModelObj.img = `${this.avengersModelObj.AvengerName}.jpg`;
  this.avengersModelObj.AvengerPowers=this.formvalue.value.AvengerPowers;

  this.api.postAvenger(this.avengersModelObj).subscribe(
    res => {
      console.log(res);
      alert("Avenger Added Successfully");
      this.getAllAvengers();
      let close = document.getElementById("cancel");
      close?.click();
      this.formvalue.reset();
      
    },
    err => {
      alert("Something went wrong");
    }
  )
}



deleteAvenger(emp:any){
  this.api.deleteAvenger(emp.id).subscribe(
    res=>
    {
      alert("Avenger Removed");
      this.getAllAvengers();
    }

  )
}
editAvenger(data:any){

  this.avengersModelObj.id=data.id;
  this.showAdd=false;
  this.showUpdate=true;

  this.formvalue.controls['AvengerName'].setValue(data.AvengerName);
  this.formvalue.controls['PlaceOfOrigin'].setValue(data.PlaceOfOrigin);
  this.formvalue.controls['Gender'].setValue(data.Gender);
  this.formvalue.controls['Hair'].setValue(data.Hair);
  this.formvalue.controls['Eyes'].setValue(data.Eyes);
  this.formvalue.controls['AvengerPowers'].setValue(data.AvengerPowers);
}
updateAvengerDetails(){
  this.avengersModelObj.AvengerName = this.formvalue.value.AvengerName;
  this.avengersModelObj.PlaceOfOrigin = this.formvalue.value.PlaceOfOrigin;
  this.avengersModelObj.Gender = this.formvalue.value.Gender;
  this.avengersModelObj.Hair = this.formvalue.value.Hair;
  this.avengersModelObj.Eyes = this.formvalue.value.Eyes;
  this.avengersModelObj.AvengerPowers=this.formvalue.value.AvengerPowers;

  this.api.updateAvenger(this.avengersModelObj,this.avengersModelObj.id).subscribe(
    res => {
      console.log(res);
      alert("Avenger Updated Successfully");
      this.getAllAvengers();
      let close = document.getElementById("cancel");
      close?.click();
      this.formvalue.reset();
      
    },
    err => {
      alert("Something went wrong");
    }
  )
}


}

export class AvengersModel {
    id: number = 0;
    AvengerName: string = '';
    PlaceOfOrigin:string='';
    Gender:string='';
    Hair:string='';
    Eyes:string='';
    AvengerPowers: string = '';
    img:string='';
    
}
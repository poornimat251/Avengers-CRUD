import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AvengersDashBoardComponent } from './avengers-dash-board.component';

describe('AvengersDashBoardComponent', () => {
  let component: AvengersDashBoardComponent;
  let fixture: ComponentFixture<AvengersDashBoardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AvengersDashBoardComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AvengersDashBoardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component } from '@angular/core';
import { Router } from '@angular/router';


@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent {
  // public searchInput:string = '';
 
  // public seriesList: Array<any> = [
  //   {
  //     "name": "Prison Break",
  //     "description": "Structural Engineer Michael Scofield turns himself into the Fox River Penitentiary in order to break out his brother Lincoln Burrows, who is on death row for the murder of the Vice President's brother. But Lincoln was set up by some of the Company (an agency formed by corrupt government officials) guys, headed by General Jonathan Krantz. Michael breaks out from Fox River with his brother Lincoln and other convicts.",
  //     "genres": "Action, Crime, Drama, Mystery, Thriller",
  //     "releaseDate": "29 August 2005 (USA)"
  //   }
  //   //Truncated for brevity
  // ]
  // public searchResult: Array<any> = [];

  constructor(private router: Router) { }
  displayAvengers() {
    this.router.navigate(['/avengers']);
  }
  // fetchSeries(event:any):any{
  //   if (event.target.value === '') {
  //     return this.searchResult = [];
  //   }
  //   this.searchResult = this.seriesList.filter((series) => {
  //     return series.name.toLowerCase().startsWith(event.target.value.toLowerCase());
  //   })
  // }
}

import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AvengersDashBoardComponent } from './avengers-dash-board/avengers-dash-board.component';
import { AvengersDataComponent } from './avengers-data/avengers-data.component';
import { HomeComponent } from './home/home.component';

const routes: Routes = [
  {path:'',redirectTo:'/home',pathMatch:'full'},
  {path:'home',component:HomeComponent},
  {path:'avengers',component:AvengersDashBoardComponent},
  {path:'avengers/:id/:AvengerName/:PlaceOfOrigin/:Gender/:Hair/:Eyes/:AvengerPowers/:img',component:AvengersDataComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

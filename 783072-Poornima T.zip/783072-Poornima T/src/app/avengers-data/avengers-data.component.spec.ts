import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AvengersDataComponent } from './avengers-data.component';

describe('AvengersDataComponent', () => {
  let component: AvengersDataComponent;
  let fixture: ComponentFixture<AvengersDataComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AvengersDataComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AvengersDataComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

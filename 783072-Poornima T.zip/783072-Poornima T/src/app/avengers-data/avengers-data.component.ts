import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-avengers-data',
  templateUrl: './avengers-data.component.html',
  styleUrls: ['./avengers-data.component.css']
})
export class AvengersDataComponent {
  public Aid:any;
  public AName:any;
  public Place:any;
  public gender:any;
  public hair:any;
  public eyes:any;
  public APowers:any;
  public IMG:any
  constructor(private route:ActivatedRoute){

  }
  ngOnInit(){
    let id=this.route.snapshot.paramMap.get('id');
    this.Aid=id;

    let AvengerName=this.route.snapshot.paramMap.get('AvengerName');
    this.AName=AvengerName;

    let PlaceOfOrigin=this.route.snapshot.paramMap.get('PlaceOfOrigin');
    this.Place=PlaceOfOrigin;

    let Gender=this.route.snapshot.paramMap.get('Gender');
    this.gender=Gender;

    let Hair=this.route.snapshot.paramMap.get('Hair');
    this.hair=Hair;

    let Eyes=this.route.snapshot.paramMap.get('Eyes');
    this.eyes=Eyes;
    
    let AvengerPowers=this.route.snapshot.paramMap.get('AvengerPowers');
    this.APowers=AvengerPowers;
    let img=this.route.snapshot.paramMap.get('img');
    this.IMG=img;

  }
}
